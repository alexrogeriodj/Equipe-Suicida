<?php
$host = "localhost";
$usuario = "root";
$senha = "";
$banco = "banco";

$conn = mysql_connect($host, $usuario, $senha) or die (mysql_error());
$db = mysql_select_db($banco, $conn) or die (mysql_error());
$charset = mysql_set_charset("utf8");
?>